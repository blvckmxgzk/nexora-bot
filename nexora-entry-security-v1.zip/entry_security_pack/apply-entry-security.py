from pathlib import Path
from datetime import datetime
import shutil

ROOT = Path('.')
STAMP = datetime.now().strftime('%Y%m%d-%H%M%S')
BACKUP = Path('/workspaces/nexo-security-backups') / f'entry-{STAMP}'

required = [
    ROOT / 'src/index.ts',
    ROOT / 'src/services/community/securityService.ts',
]
for path in required:
    if not path.exists():
        raise SystemExit(f'❌ missing required file: {path}')

# Copy packaged source files into the repo, backing up existing files.
PACK = Path(__file__).parent
for src in PACK.rglob('*'):
    if not src.is_file():
        continue
    if src.name == Path(__file__).name:
        continue
    rel = src.relative_to(PACK)
    if rel.parts[0] not in {'src', 'tests'}:
        continue

    dst = ROOT / rel
    if dst.exists():
        backup = BACKUP / rel
        backup.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(dst, backup)

    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    print(f'✅ {rel}')

# Optional GuildMembers privileged intent. It stays OFF unless the env flag is true.
index_path = ROOT / 'src/index.ts'
backup = BACKUP / 'src/index.ts'
backup.parent.mkdir(parents=True, exist_ok=True)
if not backup.exists():
    shutil.copy2(index_path, backup)

text = index_path.read_text(encoding='utf-8')
if 'NEXORA_GUILD_MEMBERS_INTENT' not in text:
    marker = '    GatewayIntentBits.Guilds,\n'
    replacement = (
        '    GatewayIntentBits.Guilds,\n'
        '    ...(process.env.NEXORA_GUILD_MEMBERS_INTENT === "true"\n'
        '      ? [GatewayIntentBits.GuildMembers]\n'
        '      : []),\n'
    )
    if marker not in text:
        raise SystemExit('❌ src/index.ts Guilds intent marker not found')
    text = text.replace(marker, replacement, 1)
    index_path.write_text(text, encoding='utf-8')
    print('✅ src/index.ts optional GuildMembers intent')
else:
    print('ℹ️ optional GuildMembers intent already present')

print()
print(f'📦 Backup: {BACKUP}')
print('🎉 NEXORA Entry Security v1 installed')
print()
print('GuildMembers Intent remains OFF unless:')
print('  NEXORA_GUILD_MEMBERS_INTENT=true')
